<?php
// This file was auto-generated from sdk-root/src/data/lightsail/2016-11-28/paginators-1.json
return [ 'pagination' => [],];
