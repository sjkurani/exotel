<?php
// This file was auto-generated from sdk-root/src/data/appsync/2017-07-25/paginators-1.json
return [ 'pagination' => [],];
